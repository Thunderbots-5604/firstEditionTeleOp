package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;

public class limeLightPractice extends OpMode {
    private Limelight3A limelight3A;
    @Override
    public void init() {
        lime
    }

    @Override
    public void loop() {

    }
}
